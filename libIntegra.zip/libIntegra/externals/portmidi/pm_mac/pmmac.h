/* pmmac.h */

extern PmDeviceID pm_default_input_device_id;
extern PmDeviceID pm_default_output_device_id;