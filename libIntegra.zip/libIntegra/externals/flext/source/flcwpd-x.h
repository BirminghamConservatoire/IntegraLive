/* 

flext - C++ layer for Max/MSP and pd (pure data) externals

Copyright (c) 2001-2003 Thomas Grill (xovo@gmx.net)
For information on usage and redistribution, and for a DISCLAIMER OF ALL
WARRANTIES, see the file, "license.txt," in this distribution.  

*/

/* This is the prefix file for CodeWarrior projects - OS X version */

#ifndef _FLEXT_CW_PD_X_H
#define _FLEXT_CW_PD_X_H

#ifndef __MWERKS__
    #error "This header file is for CodeWarrior only."
#endif

#define FLEXT_SYS 2
#define FLEXT_USE_SIMD
 
#define TARGET_API_MAC_CARBON 1
#define _POSIX_C_SOURCE

#ifndef _CW_NOPRECOMP
//  #include <MacHeadersMach-O.h> 
//  #include <MSL MacHeadersMach-O.h> 
#endif

#if __option(sym) || !__option(opt_dead_code)
    #define FLEXT_DEBUG
#endif

/* #define _LOG */

#endif
