You can use this template project file to build and debug flext-based externals on OSX
- rename the myext.xcodeproj bundle to your liking (e.g. coolext.xcodeproj)
- edit main.cpp, or add source files and library dependencies to the project
