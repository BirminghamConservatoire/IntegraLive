README.txt
Roger B. Dannenberg
2 Jan 2009

PmDefaults is a program to set default input and output devices for PortMidi
applications. After running the PmDefaults program and choosing devices,
identifiers for these devices will be returned by 
Pm_GetDefaultInputDeviceID() and Pm_GetDefaultOutputDeviceID().

Included in this directory are:

manifest.txt -- used in pmdefaults.jar
pmdefaults-icon.* -- various icons for applications
pmdefaults-license.txt -- a version of portmidi/license.txt formatted for
		       the windows installer
portmusic_logo.png -- a logo displayed by the pmdefaults application
readme-win32.txt -- this becomes the readme file for the pmdefaults
		 application. It is copied to win32/README.txt by make.bat

TO BUILD THE APPLICATION: see ../README.txt

