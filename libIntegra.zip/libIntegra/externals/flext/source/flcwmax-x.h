/* 

flext - C++ layer for Max/MSP and pd (pure data) externals

Copyright (c) 2001-2003 Thomas Grill (xovo@gmx.net)
For information on usage and redistribution, and for a DISCLAIMER OF ALL
WARRANTIES, see the file, "license.txt," in this distribution.  

*/

/*! \file flcwmax-x.h
    \brief Prefix file for CodeWarrior projects - OS X version.
*/
 
#ifndef _FLEXT_CW_MAX_X_H
#define _FLEXT_CW_MAX_X_H

//#define TARGET_API_MAC_CARBON 1
#define _POSIX_C_SOURCE
#define _POSIX_SOURCE

#include "flcwmax.h"

#endif
